<!DOCTYPE html>

<html lang="en">
    <style>
        h1{
            border: 3px solid powderblue;
            padding: 30px;
            font-family: sans-serif;
            color: powderblue;
            background: grey;
            margin-bottom: 40px;
        }
        p1{
            border: 3px solid coral;
            padding: 20px;
            color: coral;
            font-family: sans-serif;
            font-size: 30px;
            background: grey;
            margin-bottom: 40px;

        }
        b1{
            color: coral;
            font-size: 30px;
            font-weight: 800;
            font-family: sans-serif;
            border-bottom: 2px solid coral;
            margin-bottom: 40px;
        }
        form{
            padding: 20px;
            color: coral;
            font-family: sans-serif;
            font-size: 30px;
        }
    
    </style>
    <h1>WORD OF THE DAY!</h1>
    <p1>There will be a new word each time you reload! =></p1>
        <b1>
                <?PHP
                $words = ["Fluffy","Quadrouple","Banana","Octopus","Snowglobe","Skycraper"];
                shuffle ($words);
                echo $words[0]; 


                ?>
        </b1>
    <form action="phpwotd.php" method="post">
	<input type="submit" value="Get another Word!">
    </form>
            

</html>   
   