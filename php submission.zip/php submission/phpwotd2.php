<!DOCTYPE html>

<html lang="en">
    <style>
        h1{
            border: 3px solid powderblue;
            padding: 30px;
            font-family: sans-serif;
            color: powderblue;
            background: grey;
            margin-bottom: 40px;
        }
        p1{
            border: 3px solid coral;
            padding: 20px;
            color: coral;
            font-family: sans-serif;
            font-size: 30px;
            background: grey;
            margin-bottom: 40px;

        }
        b1{
            color: coral;
            font-size: 30px;
            font-weight: 800;
            font-family: sans-serif;
            border-bottom: 2px solid coral;
            margin-bottom: 40px;
        }

    
    </style>
    <h1>WORD OF THE DAY!</h1>
    <p1>There will be a new word each time you reload! =></p1>
        <b1>
                <?PHP 
                $day = date("n");
                if($day = 1)
                {
                    $word = "Fluffy";
                    $today = "Monday";
                }
                if($day = 2)
                {
                    $word = "Quadrouple";
                    $today = "Tuesday";
                }
                if($day = 3)
                {
                    $word = "Banana";
                    $today = "Wednesday";
                }
                if($day = 4)
                {
                    $word = "Octopus";
                    $today = "Thursday";
                }
                if($day = 5)
                {
                    $word = "Snowglobe";
                    $today = "Friday";
                }
                if($day = 6)
                {
                    $word = "Skycraper";
                    $today = "Saturday";
                }
                if($day = 7)
                {
                    $word = "Rolecall";
                    $today = "Sunday";
                }
                echo $today;
                echo $word;


                ?>
        </b1>

            

</html>   
   