<!DOCTYPE html>

<html lang="en">

    <body>
        <meta charset="utf-8" />
     <?PHP
        $colors = ["red","green","blue"];
        echo '<ol>'; 
            for($i=0;$i<count($colors);$i++)
            {
              echo '<li>' . $colors[$i] . '</li>'; 
            }
            echo '</ol>';
        $links = ['<a href="http://www.rit.edu">RIT</a>','<a href="http://www.rpi.edu">RPI</a>','<a href="http://www.monroecc.edu">MCC</a>']; 
                echo '<ul>'; 
            for($j=0;$j<count($links);$j++)
            {
              echo '<li>' . $links[$j] . '</li>'; 
            }
           echo '</ul>';

           
            


    ?>
    </body>

</html>   
   